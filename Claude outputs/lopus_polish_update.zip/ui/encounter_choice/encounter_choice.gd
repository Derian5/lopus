class_name EncounterChoiceScreen
extends Control

signal encounter_selected(encounter_id: StringName)

const THREAT_COLORS := {
	"Low": Color(0.3, 0.78, 0.42),
	"Moderate": Color(0.95, 0.74, 0.24),
	"High": Color(0.95, 0.45, 0.16),
	"Boss": Color(0.88, 0.2, 0.18),
}
const THREAT_PIPS := {"Low": 1, "Moderate": 2, "High": 3, "Boss": 4}
const UNKNOWN_COLOR := Color(0.58, 0.36, 0.95)

var run_state: RunState

@onready var route_label: Label = %RouteLabel
@onready var cards: HBoxContainer = %Cards
@onready var status_label: Label = %StatusLabel


func set_run_state(value: RunState) -> void:
	run_state = value
	if not is_node_ready():
		await ready
	_render()


func _set_feedback(message: String, is_error := false) -> void:
	status_label.text = message
	status_label.add_theme_color_override("font_color", Color("e38375") if is_error else Color("91c99a"))


func _render() -> void:
	for child in cards.get_children():
		child.queue_free()
	if run_state == null:
		status_label.text = "No active expedition."
		return
	route_label.text = "ACT %d  /  BATTLE %d" % [run_state.current_act, run_state.encounter_index + 1]
	for index in run_state.available_encounter_ids.size():
		var encounter_id := run_state.available_encounter_ids[index]
		var encounter := get_node("/root/ContentRegistry").get_definition(encounter_id, false) as EncounterDefinition
		if encounter != null:
			cards.add_child(_build_card(encounter, index))
	status_label.text = "Study the opposition and click a card to march. This choice cannot be changed."


func _build_card(encounter: EncounterDefinition, _visual_index := 0) -> Control:
	var accent := _threat_color(encounter)
	var panel := PanelContainer.new()
	panel.custom_minimum_size = Vector2(410.0, 430.0)
	panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	panel.mouse_filter = Control.MOUSE_FILTER_STOP
	panel.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	panel.tooltip_text = "Click to choose this battle."
	panel.gui_input.connect(_on_card_input.bind(encounter.id))
	var style := UiStyle.accent_panel(accent, false, 18)
	style.content_margin_left = 30
	style.content_margin_top = 30
	style.content_margin_right = 30
	style.content_margin_bottom = 26
	panel.add_theme_stylebox_override("panel", style)

	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 12)
	panel.add_child(column)

	var threat_row := HBoxContainer.new()
	threat_row.add_theme_constant_override("separation", 6)
	column.add_child(threat_row)
	var gem := OrnateFrame.gem_texture(OrnateFrame.gem_for_color(accent))
	var bronze_gem := OrnateFrame.gem_texture(&"bronze")
	var pips := int(THREAT_PIPS.get(encounter.difficulty_hint, 2))
	for pip in 4:
		var icon := TextureRect.new()
		icon.texture = gem if pip < pips else bronze_gem
		icon.custom_minimum_size = Vector2(22, 22)
		icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		icon.modulate = Color(1.25, 1.25, 1.25, 1.0) if pip < pips else Color(0.7, 0.62, 0.55, 0.75)
		threat_row.add_child(icon)
	var difficulty := Label.new()
	difficulty.text = "  %s THREAT" % encounter.difficulty_hint.to_upper() if not encounter.is_unknown else "  UNKNOWN THREAT"
	difficulty.add_theme_color_override("font_color", accent.lightened(0.28))
	difficulty.add_theme_font_size_override("font_size", 18)
	threat_row.add_child(difficulty)

	var title := Label.new()
	title.text = encounter.display_name.to_upper()
	title.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	title.theme_type_variation = &"HeaderLabel"
	title.add_theme_color_override("font_color", accent.lightened(0.4))
	title.add_theme_font_size_override("font_size", 32)
	column.add_child(title)
	column.add_child(HSeparator.new())
	var description := Label.new()
	description.text = encounter.description
	description.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	description.size_flags_vertical = Control.SIZE_EXPAND_FILL
	description.add_theme_color_override("font_color", Color("b9c3cf"))
	description.add_theme_font_size_override("font_size", 18)
	column.add_child(description)

	var details := PanelContainer.new()
	details.theme_type_variation = &"InsetPanel"
	column.add_child(details)
	var properties := Label.new()
	properties.text = _properties_text(encounter)
	properties.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	properties.add_theme_color_override("font_color", Color("d6dde5"))
	properties.add_theme_font_size_override("font_size", 17)
	details.add_child(properties)

	var reward := Label.new()
	reward.text = "REWARD  %d GOLD" % encounter.gold_reward
	reward.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	reward.add_theme_color_override("font_color", UiStyle.GOLD)
	reward.add_theme_font_size_override("font_size", 24)
	reward.theme_type_variation = &"NumberLabel"
	reward.add_theme_color_override("font_color", UiStyle.GOLD)
	column.add_child(reward)
	var frame := UiStyle.add_frame(panel, accent, 0.0, -26.0)
	frame.crest_width = 110.0
	frame.corner_gem_size = 26.0
	panel.mouse_entered.connect(func() -> void: _set_card_glow(frame, true))
	panel.mouse_exited.connect(func() -> void: _set_card_glow(frame, false))
	return panel


func _on_card_input(event: InputEvent, encounter_id: StringName) -> void:
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		encounter_selected.emit(encounter_id)


func _set_card_glow(frame: OrnateFrame, enabled: bool) -> void:
	if not is_instance_valid(frame):
		return
	frame.pulse = enabled
	var tween := frame.create_tween()
	tween.tween_property(frame, "glow", 0.85 if enabled else 0.0, 0.18)


func _threat_color(encounter: EncounterDefinition) -> Color:
	if encounter.is_unknown:
		return UNKNOWN_COLOR
	return THREAT_COLORS.get(encounter.difficulty_hint, THREAT_COLORS["Moderate"])


func _properties_text(encounter: EncounterDefinition) -> String:
	var lines: Array[String] = []
	for property in encounter.key_properties:
		lines.append("+  %s" % property)
	if lines.is_empty():
		lines.append("+  Opposition details unknown")
	if encounter.has_reinforcements():
		if not encounter.is_unknown:
			lines.append("+  Initial: %s" % _enemy_composition(encounter.enemy_ids))
			lines.append("+  Reinforcements: %s" % _enemy_composition(encounter.reinforcement_enemy_ids))
		else:
			lines.append("+  Reinforcement composition concealed")
		var enemy_word := "enemy" if encounter.reinforcement_alive_threshold == 1 else "enemies"
		lines.append("+  Reinforcements arrive at %d %s remaining" % [encounter.reinforcement_alive_threshold, enemy_word])
		lines.append("+  Entry: %s" % _entry_direction_text(encounter.reinforcement_entry_direction))
	return "\n".join(lines)


func _enemy_composition(enemy_ids: Array[StringName]) -> String:
	var counts: Dictionary = {}
	for enemy_id in enemy_ids:
		var enemy := get_node("/root/ContentRegistry").get_definition(enemy_id, false) as EnemyDefinition
		var enemy_name := enemy.display_name if enemy != null else String(enemy_id)
		counts[enemy_name] = int(counts.get(enemy_name, 0)) + 1
	var parts := PackedStringArray()
	for enemy_name in counts:
		parts.append("%s x%d" % [enemy_name, counts[enemy_name]])
	return ", ".join(parts)


func _entry_direction_text(direction: int) -> String:
	return "right side" if direction == EncounterDefinition.ReinforcementEntryDirection.RIGHT_SIDE else "all sides"
